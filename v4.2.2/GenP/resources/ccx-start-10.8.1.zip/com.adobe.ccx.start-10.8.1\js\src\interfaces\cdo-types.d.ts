/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2023 Adobe
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe and its suppliers, if any. The intellectual
 * and technical concepts contained herein are proprietary to Adobe
 * and its suppliers and are protected by all applicable intellectual
 * property laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe.
 **************************************************************************/
import type { ARCHIVE_FOLDER_PATH, Action, AssetSyncStateStore, CDORootPathType, CDOStoreType, EventType, ICallbacks, IFileCapabilitiesConfig, IHostProductData, IIMSData, IImportData, IMoveDialogResult, IReadOnlySelectionStore, ROOT_FOLDER_PATH, SHARED_WITH_YOU_PATH } from '@ccx/ccx-cdo';
export type { ICallbacks, IImportData, IHostProductData, IIMSData, IMoveDialogResult, IFileCapabilitiesConfig, CDOStoreType, EventType, AssetSyncStateStore, Action, CDORootPathType, ROOT_FOLDER_PATH, SHARED_WITH_YOU_PATH, ARCHIVE_FOLDER_PATH, IReadOnlySelectionStore, };
//# sourceMappingURL=cdo-types.d.ts.map