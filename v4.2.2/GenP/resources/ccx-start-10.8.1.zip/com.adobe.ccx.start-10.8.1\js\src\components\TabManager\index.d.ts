/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2025 Adobe
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe and its suppliers, if any. The intellectual
 * and technical concepts contained herein are proprietary to Adobe
 * and its suppliers and are protected by all applicable intellectual
 * property laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe.
 **************************************************************************/
export { registerTabManagerElement } from './TabManagerElement';
export { BUILT_IN_TAB_CONFIGS, CDO_ROUTES, DEFAULT_VIEW_OPTIONS, TAB_ID_TO_CDO_ROUTE, TAB_ID_TO_CONTENT_VIEW_TYPE, applyNavigationEvent, } from './TabManagerShared';
export type { TabId, BuiltInTabConfig, CustomTabConfigInput, VisibleTabConfig, TabManagerState, TabManagerInternalState, ViewOptions, NavigateEventDetail, } from './TabManagerShared';
export { isBuiltInTabId } from './TabManagerShared';
//# sourceMappingURL=index.d.ts.map