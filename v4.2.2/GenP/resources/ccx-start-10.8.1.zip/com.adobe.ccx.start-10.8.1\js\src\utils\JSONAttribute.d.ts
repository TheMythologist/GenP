/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2025 Adobe
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe and its suppliers, if any. The intellectual
 * and technical concepts contained herein are proprietary to Adobe
 * and its suppliers and are protected by all applicable intellectual
 * property laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe.
 **************************************************************************/
export declare class JSONAttribute<JSONShape> {
    private element;
    private attributeName;
    /**
     * Extra validation to run on the value after parsing.
     */
    private validator?;
    private cache;
    constructor(element: HTMLElement, attributeName: string, validator?: (value: JSONShape) => boolean);
    get value(): JSONShape | undefined;
}
//# sourceMappingURL=JSONAttribute.d.ts.map