/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2024 Adobe
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe and its suppliers, if any. The intellectual
 * and technical concepts contained herein are proprietary to Adobe
 * and its suppliers and are protected by all applicable intellectual
 * property laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe.
 **************************************************************************/
import type { getLaunchUAP as GetLaunchUAPType } from '../components/DocPickerElement';
/**
 * launchUAP is an async wrapper around `getLaunchUAP`. It should be used by
 * UAB web components to lazy import and load UAP. rather than importing from
 * components/DocPickerElement directly.
 */
export declare function launchUAP(...args: Parameters<ReturnType<typeof GetLaunchUAPType>>): Promise<any>;
//# sourceMappingURL=launchUAP.d.ts.map