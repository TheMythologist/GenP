/* i386-linux.kernel.vmlinux-head.h
   created from i386-linux.kernel.vmlinux-head.bin, 37 (0x25) bytes

   This file is part of the UPX executable compressor.

   Copyright (C) 1996-2025 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 1996-2025 Laszlo Molnar
   Copyright (C) 2000-2025 John F. Reiser
   All Rights Reserved.

   UPX and the UCL library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYING.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Markus F.X.J. Oberhumer              Laszlo Molnar
   <markus@oberhumer.com>               <ezerotven+github@gmail.com>

   John F. Reiser
   <jreiser@users.sourceforge.net>
 */

/* clang-format off */

#define STUB_I386_LINUX_KERNEL_VMLINUX_HEAD_SIZE    37
#define STUB_I386_LINUX_KERNEL_VMLINUX_HEAD_ADLER32 0x81fb1575
#define STUB_I386_LINUX_KERNEL_VMLINUX_HEAD_CRC32   0xf78f5286

unsigned char stub_i386_linux_kernel_vmlinux_head[37] = {
/* 0x0000 */ 140,200,131,192,  8,142,216,142,192,142,224,142,232,141,142,  0,
/* 0x0010 */ 144,  0,  0,137, 73,248,137, 65,252, 15,178, 97,248,106,  0,157,
/* 0x0020 */ 232,252,255,255,255
};
